/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/}

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "Task_NFC.h"
#include "NFC_SPI.h"

int main(void)
{
  /* USER CODE BEGIN 1 */
	CPU_CACHE_Enable();
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  NFC_SPI_Init();		// Initialization NFC peripheral of Cortex-M7
  /* Delay of 10 second blocking for module ESP8266 */
  HAL_Delay(10000);
  /* USER CODE END 2 */

  if (TaskNFC_Started() < 0)
  {
	  while(1)
	  {
		  HAL_GPIO_TogglePin(GPIOJ, GPIO_PIN_13);
		  HAL_Delay(1000);
	  }
  }

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
}