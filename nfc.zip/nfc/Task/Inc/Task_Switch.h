/*
 * Task_Switch.h
 *
 *  Created on: Jun 19, 2020
 *      Author: hanes
 */

#ifndef INC_TASK_SWITCH_H_
#define INC_TASK_SWITCH_H_


int8_t TaskSwitch_Started(void);

#endif /* INC_TASK_SWITCH_H_ */
